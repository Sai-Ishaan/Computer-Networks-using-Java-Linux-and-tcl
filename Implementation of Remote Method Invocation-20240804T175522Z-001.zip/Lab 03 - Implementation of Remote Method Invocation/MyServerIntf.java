//function prototype
import java.rmi.*;

public interface MyServerIntf extends Remote		//remote interface
{	int i=0;
	int reverse(int d) throws RemoteException;
	int add_digits(int a) throws RemoteException;
}
