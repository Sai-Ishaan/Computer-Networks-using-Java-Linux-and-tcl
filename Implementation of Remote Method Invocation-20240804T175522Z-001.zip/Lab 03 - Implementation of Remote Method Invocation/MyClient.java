import java.net.*;
import java.rmi.*;

public class MyClient
{
	public static void main(String[] arg)
	{
		try 	
		{
		String sName = "rmi://"+arg[0]+"/MyS";
		
		MyServerIntf asif = (MyServerIntf)Naming.lookup(sName);  // requesting remote objects on 							            // the server
			
		int d1= Integer.parseInt(arg[1]);
		System.out.println("Sum of digits : "+asif.add_digits(d1));
		System.out.println("Reverse of number: "+asif.reverse(d1));

		}
		catch(Exception e)
		{
			System.out.println("Exception: "+e);
		}
	}
}
