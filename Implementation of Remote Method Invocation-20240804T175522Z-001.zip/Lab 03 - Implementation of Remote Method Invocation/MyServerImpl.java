//definition of MyServerIntf
import java.rmi.*;
import java.rmi.server.*;

// UnicastRemoteObject supports for point-to-point active object references (invocations, parameters, and // results) using TCP streams.

public class MyServerImpl extends UnicastRemoteObject implements MyServerIntf
{
	MyServerImpl() throws RemoteException
	{}

	public int add_digits(int a) throws RemoteException
	{
		int sum = 0;
		while(a > 0)
		{
			sum += a%10;
			a = a/10;
		}
		return sum;
	}
	public int reverse(int a) throws RemoteException{
		int rev = 0;
		while(a > 0){
			rev = rev*10 + a%10;
			a = a/10;
		}
		return rev;
	}


	}


// End of MyServerImpl.java
	

